# package.json Guide (Why no inline comments)

`package.json` is strict JSON, so normal comments like `// ...` are not allowed.
To keep the file valid and still explain everything, this guide provides line-by-line purpose notes.

## Top-level fields
- `name`
  - Purpose: Package/app short name.
- `version`
  - Purpose: App version for release tracking.
- `description`
  - Purpose: Human-readable summary.
- `keywords`
  - Purpose: Search tags for tooling/discovery.
- `main`
  - Purpose: Entry file hint (not critical for UI5 runtime app).
- `dependencies`
  - Purpose: Runtime npm packages (currently none).
- `devDependencies`
  - Purpose: Build/dev tools only.
- `scripts`
  - Purpose: Shortcut commands used during development and testing.
- `sapuxLayer`
  - Purpose: SAP adaptation/project layer indicator.

## Script purposes
- `start`
  - Purpose: Run local FLP preview for app preview tile.
- `start-local`
  - Purpose: Run local FLP preview using `ui5-local.yaml`.
- `build`
  - Purpose: Create optimized `dist/` build output.
- `deploy`
  - Purpose: Run deployment verification.
- `deploy-config`
  - Purpose: Create deployment config interactively.
- `start-noflp`
  - Purpose: Start app directly without FLP shell.
- `int-test`
  - Purpose: Open OPA integration test page.
- `unit-test`
  - Purpose: Open QUnit unit test page.
- `start-variants-management`
  - Purpose: Open variant management preview route.

## Dev dependency purposes
- `@ui5/cli`
  - Purpose: UI5 build and serve tooling.
- `@sap/ux-ui5-tooling`
  - Purpose: SAP Fiori tools middleware (preview/proxy/app reload).

## Work Zone note
For Work Zone launch, inbounds are defined in `webapp/manifest.json` under:
- `sap.app -> crossNavigation -> inbounds`

WORKZONE relevant:
- `webapp/manifest.json` -> `sap.app.crossNavigation.inbounds`
- `webapp/manifest.json` -> `sap.cloud`

Related runtime/deployment context:
- `build` script prepares deployable output.
- Deployed app content is what Work Zone launches.

Detailed SAP Work Zone logic guide:
- `webapp/workzone-guide.md`
