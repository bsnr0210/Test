# SAP Work Zone Logic Guide

This guide explains exactly where SAP Work Zone related logic is configured in this app.

## 1) Where Work Zone launch logic is defined
File: `webapp/manifest.json`

WORKZONE relevant:
- `sap.app -> crossNavigation -> inbounds`

Main section:
- `sap.app -> crossNavigation -> inbounds`

Current inbound:
- `zDemo-display`
  - `semanticObject`: `ZDemo`
  - `action`: `display`
  - `title`: app title from i18n
  - `signature`: accepts additional parameters

Purpose:
- This is the intent definition Work Zone uses to launch the app tile.

## 2) Where cloud service identity is defined
File: `webapp/manifest.json`

WORKZONE relevant:
- `sap.cloud`

Section:
- `sap.cloud`
  - `public: true`
  - `service: nagi.demo`

Purpose:
- Identifies app service context for BTP/Work Zone content integration.

## 3) How routing connects after launch
File: `webapp/manifest.json`

Section:
- `sap.ui5 -> routing`

Important parts:
- default route `RouteV1`
- target pages `TargetV1`, `TargetV2`
- root container id `app`

Purpose:
- After Work Zone launches the app, UI5 routing decides which internal page opens.

## 4) Which npm scripts are related
File: `package.json`

Useful scripts:
- `build` -> prepares deployable `dist`
- `deploy` -> runs deployment verification flow
- `deploy-config` -> generates deploy config

Purpose:
- Build and deploy pipeline used before exposing app content in Work Zone.

## 5) Local preview vs Work Zone runtime
Local preview scripts (`start`, `start-local`, `start-noflp`) are for development only.

In Work Zone runtime:
- Tile/intent resolution uses `crossNavigation.inbounds`.
- App is served from deployed HTML5 app content.

## 6) End-to-end Work Zone checklist
1. Ensure `manifest.json` has valid inbound (semantic object/action).
2. Build app (`npm run build`) successfully.
3. Deploy app to BTP HTML5 repository / managed runtime.
4. Add app in Work Zone Content Manager.
5. Assign to role and publish site.
6. Open tile and verify inbound launches app.

## 7) Common issues and fixes
- Tile not opening app:
  - Check semantic object/action in inbound matches Work Zone content entry.
- App opens but wrong page:
  - Check default route pattern and target in `sap.ui5.routing`.
- App not visible in content manager:
  - Check deployment completed and app is assigned to provider/subaccount content.

## 8) For this project (current status)
- Inbound is present in `manifest.json`.
- `sap.cloud` service is present.
- Build is passing.
- App is ready for Work Zone content registration.
