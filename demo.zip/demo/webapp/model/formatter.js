// sap.ui.define creates a UI5 module file.
// Empty dependency array means this module does not need external UI5 modules to load.
sap.ui.define([], () => {
    // "use strict" enables safer JavaScript rules and catches common mistakes early.
    "use strict";

    // return { ... } sends this helper object (collection of functions) to any file that imports formatter.
    return {
        // Quick line guide for this file:
        // toUpperCase(sValue) -> formatter used by XML binding to transform display text.
        // if (!sValue) return "" -> protects UI from null/undefined values.
        // return sValue.toUpperCase() -> sends transformed value to bound control text.
        /**
         * Purpose: Convert text to uppercase for display in formatter demo.
         * How it works: If value is empty, return empty string; otherwise return value.toUpperCase().
         */
        toUpperCase: function(sValue) {
            if (!sValue) {
                return "";
            }

            // Returns transformed text back to the UI binding.
            return sValue.toUpperCase();
        }
    };
});