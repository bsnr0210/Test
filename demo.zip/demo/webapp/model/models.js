// sap.ui.define creates a UI5 module file.
// Array items are dependencies to load first; callback parameters receive those loaded modules.
sap.ui.define([
    "sap/ui/model/json/JSONModel",
    "sap/ui/Device"
],
function (JSONModel, Device) {
    // "use strict" enables safer JavaScript rules and catches common mistakes early.
    "use strict";

    // return { ... } sends helper methods (like createDeviceModel) to files that import this module.
    return {
        // Quick line guide for this file:
        // new JSONModel(Device) -> wrap UI5 Device API data in a bindable model.
        // setDefaultBindingMode("OneWay") -> UI reads device flags; app should not write back.
        // return oModel -> send completed model instance to caller (Component.js).
        /**
         * Purpose: Create a global "device" model (phone/tablet/desktop info).
         * How it works:
         * 1) Wraps sap/ui/Device data inside JSONModel.
         * 2) Sets OneWay mode because app should read device info, not write it.
         * 3) Returns model to Component.js where it is attached as "device" model.
         * @returns {sap.ui.model.json.JSONModel} Device info model.
         */
        createDeviceModel: function () {
            var oModel = new JSONModel(Device);
            oModel.setDefaultBindingMode("OneWay");
            // Returns completed device model back to Component.js.
            return oModel;
        }
    };

});