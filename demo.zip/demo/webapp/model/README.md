# Model Guide (Kid-Friendly)

This app keeps all data in this `model` folder.

## Big idea
- `manifest.json` tells UI5 which model file to load.
- XML view reads and writes values using bindings like `{modelName>/path}`.
- Controller updates model values using `setProperty("/path", value)`.
- When model changes, UI updates automatically.

## Where each model is used
- `sharedData.json`
  - Used in: Demo for Controls, V2 transfer demo
  - Purpose: Share one input value between views/components

- `hooksData.json`
  - Used in: Hook Methods Example
  - Purpose: Show lifecycle status (`onInit`, `onBeforeRendering`, etc.)

- `basicMethodsData.json`
  - Used in: basic string-method result logic in controller
  - Purpose: Keep input/output fields for simple string operations

- `comparisonData.json`
  - Used in: Comparison Operators block
  - Purpose: Left value, right value, operator, result, explanation

- `arithmeticData.json`
  - Used in: Arithmetic Operators block
  - Purpose: Numbers, operator, result, explanation

- `logicalData.json`
  - Used in: Logical Operators block
  - Purpose: Boolean values, operator, result, explanation

- `stringMethodsData.json`
  - Used in: String Methods block
  - Purpose: Input text and all computed method outputs

- `mathObjectsData.json`
  - Used in: Math Objects block
  - Purpose: Number inputs and all computed Math outputs

- `controlMethodsData.json`
  - Used in: Basic Methods of Controls block
  - Purpose: Show method output text and enable/disable state

- `fragmentDemoData.json`
  - Used in: Fragment Demo block
  - Purpose: Status text for fragment actions and selected row

- `bindingExamplesData.json`
  - Used in: Binding Types Example
  - Purpose: Property, list products, and selected item details

- `testData.json`
  - Used in: Table Example and Table Fragment
  - Purpose: Table rows and search text

- `oneTimeData.json`, `oneWayData.json`, `twoWayData.json`
  - Used in: JSON Model Binding Modes block
  - Purpose: Demonstrate OneTime, OneWay, and TwoWay behavior

## Binding quick examples
- Property binding: `{shared>/inputValue}`
  - One control property is connected to one model value.

- Aggregation binding: `items="{test>/tableItems}"`
  - Repeats row template for every array item.

- Element binding: `binding="{bindingExamples>/products/0}"`
  - Child controls read relative properties from one selected object.

- Expression binding: `{= ${model>/value} ? 'Yes' : 'No' }`
  - Simple inline logic directly in XML.
