/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["nagi/demo/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
