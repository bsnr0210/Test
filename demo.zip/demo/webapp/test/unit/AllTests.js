sap.ui.define([
	"nagi/demo/test/unit/controller/V1.controller"
], function () {
	"use strict";
});
