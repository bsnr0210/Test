# Manifest Guide (Simple and Kid-Friendly)

This file explains how our app uses `manifest.json`.

Think of `manifest.json` like the app's master plan:
- It tells UI5 which libraries to load.
- It tells UI5 where model data files are.
- It tells UI5 which view opens first.
- It tells UI5 how navigation (routing) works.

## 1) App identity
In `sap.app` we define:
- app id
- app title
- app description
- i18n file location

Purpose:
- So UI5 knows what this app is and what text resources to use.

## 2) UI framework and libraries
In `sap.ui5 -> dependencies -> libs` we load:
- `sap.m`
- `sap.ui.core`
- `sap.ui.layout`

Purpose:
- `sap.m`: buttons, inputs, tables, pages
- `sap.ui.core`: base framework features
- `sap.ui.layout`: layout controls like form/grid

## 3) Models (most important)
In `sap.ui5 -> models` we define named models.

Each model has:
- a name (example: `test`, `comparisonDemo`)
- a type (`sap.ui.model.json.JSONModel`)
- a data source (`uri` pointing to file in `webapp/model`)

Purpose:
- Keep data outside controller code.
- Make bindings easy and reusable.

### Current model map
- `shared` -> `model/sharedData.json`
- `test` -> `model/testData.json`
- `bindingExamples` -> `model/bindingExamplesData.json`
- `oneTimeModel` -> `model/oneTimeData.json`
- `oneWayModel` -> `model/oneWayData.json`
- `twoWayModel` -> `model/twoWayData.json`
- `hooks` -> `model/hooksData.json`
- `basicMethods` -> `model/basicMethodsData.json`
- `comparisonDemo` -> `model/comparisonData.json`
- `arithmeticDemo` -> `model/arithmeticData.json`
- `logicalDemo` -> `model/logicalData.json`
- `stringMethodsDemo` -> `model/stringMethodsData.json`
- `mathObjectsDemo` -> `model/mathObjectsData.json`
- `controlMethodsDemo` -> `model/controlMethodsData.json`
- `fragmentDemo` -> `model/fragmentDemoData.json`

## 4) How binding works with manifest models
Once a model is defined in manifest, view and controller can use it by name.

### In XML view
Property binding example:
- `value="{shared>/inputValue}"`

Meaning:
- Read/write `inputValue` from model `shared`.

Aggregation binding example:
- `items="{test>/tableItems}"`

Meaning:
- Build list/table rows from array `tableItems` in model `test`.

Element binding example:
- `binding="{bindingExamples>/products/0}"`

Meaning:
- Child controls inside read properties from selected product object.

Expression binding example:
- `text="{= ${bindingExamples>/propertyValue} ? 'Yes' : 'No' }"`

Meaning:
- Small inline logic directly in XML.

### In controller
Read model:
- `this.getView().getModel("comparisonDemo")`

Write model:
- `oModel.setProperty("/result", "true")`

Purpose:
- Controller updates data, UI updates automatically because of binding.

## 5) Routing (navigation)
In `sap.ui5 -> routing` we define:
- routes (`RouteV1`, `RouteV2`)
- targets (`TargetV1`, `TargetV2`)

Purpose:
- Move between views using router, for example Next/Back buttons.

## 6) Root view
In `sap.ui5 -> rootView` we set app entry view.

Purpose:
- This is the first view UI5 opens when app starts.

## 7) Why we moved data to model folder
Benefits:
- Cleaner controller (less hardcoded data)
- Easy to understand where data comes from
- Easy to edit demo defaults in one place
- Better for teamwork and maintenance

## 8) Quick troubleshooting checklist
If data is not showing:
1. Check model name in XML (left side before `>`)
2. Check path in XML (right side after `>`)
3. Check model exists in `manifest.json`
4. Check JSON file path in `uri`
5. Check JSON syntax is valid

If navigation fails:
1. Check route names in manifest
2. Check `navTo("RouteName")` spelling in controller

If binding mode demo looks wrong:
1. Check model binding mode in manifest (`OneTime`, `OneWay`, `TwoWay`)
2. Check runtime `bindProperty` mode in controller

## 9) SAP Work Zone specific logic
In this app, Work Zone launch logic is in `sap.app -> crossNavigation -> inbounds`.

WORKZONE relevant:
- `sap.app -> crossNavigation -> inbounds`
- `sap.cloud`

Note:
- `manifest.json` is strict JSON, so inline comments are not allowed there.
- This guide is used as the comment/explanation companion for those keys.

Purpose:
- Defines intent (semantic object + action) used by Work Zone tile launch.

Also check:
- `sap.cloud` section for service identity used in BTP/Work Zone integration.

Detailed guide:
- See `webapp/workzone-guide.md` for full end-to-end explanation and checklist.
