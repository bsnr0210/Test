// sap.ui.define creates a UI5 module file.
// Array items are dependencies to load first; callback parameters receive those loaded modules.
sap.ui.define([
    "sap/ui/core/UIComponent",
    "nagi/demo/model/models"
], (UIComponent, models) => {
    // "use strict" enables safer JavaScript rules and catches common mistakes early.
    "use strict";

    // UIComponent.extend(...) creates our app component class and returns it to UI5.
    return UIComponent.extend("nagi.demo.Component", {
        // Quick line guide for this file:
        // metadata.manifest = "json" -> tells UI5 to load app configuration from manifest.json.
        // interfaces include IAsyncContentCreation -> allows async root content creation flow.
        // UIComponent.prototype.init.apply(this, arguments) -> runs parent initialization first.
        // this.setModel(models.createDeviceModel(), "device") -> expose device info model globally.
        // this.getRouter().initialize() -> activates manifest routes and opens initial target view.
        // Component is the app entry point. UI5 calls methods here first.
        metadata: {
            manifest: "json",
            interfaces: [
                "sap.ui.core.IAsyncContentCreation"
            ]
        },

        /**
         * Purpose: Start the app and prepare global resources.
         * How it works:
         * 1) Calls parent init.
         * 2) Sets device model (desktop/tablet/phone info).
         * 3) Starts router so App/V1/V2 navigation works.
         */
        init() {
            // call the base component's init function
            UIComponent.prototype.init.apply(this, arguments);

            // setModel(model, "device") attaches global model so views can use it as "device>..."
            this.setModel(models.createDeviceModel(), "device");

            // getRouter().initialize() reads routes from manifest and opens first target
            this.getRouter().initialize();
        }
    });
});