// sap.ui.define creates a UI5 module file.
// Array items are dependencies to load first; callback parameters receive those loaded modules.
sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/Fragment",
    "sap/m/MessageToast",
    "sap/ui/model/BindingMode",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "nagi/demo/model/formatter"
], (Controller, Fragment, MessageToast, BindingMode, Filter, FilterOperator, formatter) => {
    // "use strict" enables safer JavaScript rules and catches common mistakes early.
    "use strict";

    // Controller.extend(...) creates our V1 controller class and returns it to UI5.
    return Controller.extend("nagi.demo.controller.V1", {
        // Used by the Formatter block in the view.
        formatter: formatter,

        // Quick API cheat sheet for kids (line-by-line meaning used in this file):
        // this.getView() -> gets current view object (your current page container).
        // this.byId("...") -> finds one control inside this view by id.
        // this.getOwnerComponent() -> gets app component to access global model/router.
        // this.getOwnerComponent().getRouter().navTo("RouteX") -> navigate to another route/page.
        // oEvent.getParameter("name") -> reads event payload value (typed text, selected item, etc.).
        // this.getView().getModel("name") -> gets a named model attached to view/component.
        // oModel.getProperty("/path") -> reads value from JSON model path.
        // oModel.setProperty("/path", v) -> writes value to model path and updates bound UI.
        // oTable.getBinding("items") -> gets items binding object (used for filter/sort on table/list).
        // oBinding.filter(...) -> applies/clears filters on a bound list/table.
        // new Filter(...) -> creates a filter condition for binding data.
        // oSelectedItem.getBindingContext("model") -> gets selected row context from named model.
        // oContext.getPath() -> returns path of selected object (example: /items/2).
        // oContext.getObject() -> returns actual selected row object.
        // control.bindProperty(...) -> links one control property (like value) to model path.
        // control.unbindProperty("value") -> removes existing value binding from control.
        // control.bindElement(...) -> sets object context for a container and its child controls.
        // control.toggleStyleClass("class") -> add/remove CSS class on control.
        // control.hasStyleClass("class") -> checks if CSS class is currently applied.
        // control.setText(...) / setValue(...) / setEnabled(...) -> updates control state directly.
        // Fragment.load(...) -> async load of reusable UI fragment, returns Promise.
        // promise.then(function(v) { ... }) -> runs callback after async operation completes.
        // this.getView().addDependent(control) -> attach popup/dialog lifecycle to view for cleanup/model propagation.
        // Number(value) -> convert string input into number.
        // Number.isNaN(value) -> true when conversion result is not a valid number.
        // Math.* (sqrt/pow/round/...) -> built-in math utility methods.

        /**
         * Purpose: Prepare demo page state when V1 view is created.
         * How it works: Marks hook status, computes initial outputs, and sets up special bindings.
         */
        onInit() {
            // Hook status values are stored in the "hooks" model from manifest.json.
            this._setHookState("/onInit", "Executed");

            // Initialize output values for all demo blocks.
            // Input values come from JSON files in webapp/model and are loaded via manifest models.
            this._updateBasicMethodsResults();
            this._evaluateComparison();
            this._evaluateArithmetic();
            this._evaluateLogical();
            this._applyStringMethods();
            this._applyMathObjects();

            // For binding-mode demo we attach bindings in code so mode behavior is obvious.
            this._setupBindingModeDemoBindings();

            // alert("Hook triggered: onInit");
        },

        /**
         * Purpose: Configure demo fields to show TwoWay, OneWay, and OneTime behavior.
         * How it works: Rebinds selected inputs in code with explicit binding modes.
         */
        _setupBindingModeDemoBindings: function() {
            // TwoWay: UI <-> model both directions.
            this.byId("twoWayBaseInputV1").bindProperty("value", {
                path: "twoWayModel>/baseValue",
                mode: BindingMode.TwoWay
            });
            this.byId("twoWayOutputInputV1").bindProperty("value", {
                path: "twoWayModel>/baseValue",
                mode: BindingMode.TwoWay
            });

            // Source input is TwoWay so user typing updates model.
            this.byId("oneWayInputV1").bindProperty("value", {
                path: "oneWayModel>/baseValue",
                mode: BindingMode.TwoWay
            });
            // Target input is OneWay so model updates UI, but typing here does not update model.
            this.byId("oneWayOutputInputV1").bindProperty("value", {
                path: "oneWayModel>/baseValue",
                mode: BindingMode.OneWay
            });

            // Source is editable and updates model; one-time target is attached when user clicks button.
            this.byId("oneTimeInputV1").bindProperty("value", {
                path: "oneTimeModel>/baseValue",
                mode: BindingMode.TwoWay
            });
        },

        /**
         * Purpose: Demonstrate OneTime binding on demand.
         * How it works: Unbinds the target field and rebinds it once with OneTime mode.
         */
        onLoadOneTimeOutputPress: function() {
            // Rebind with OneTime mode so target reads model once and then stops updating.
            var oOutput = this.byId("oneTimeOutputInputV1");
            oOutput.unbindProperty("value");
            oOutput.bindProperty("value", {
                path: "oneTimeModel>/baseValue",
                mode: BindingMode.OneTime
            });
        },

        /**
         * Purpose: Update hook demo before UI renders.
         * How it works: Writes "Executed" status into hooks model.
         */
        onBeforeRendering: function() {
            this._setHookState("/onBeforeRendering", "Executed");
            // alert("Hook triggered: onBeforeRendering");
        },

        /**
         * Purpose: Update hook demo after UI renders.
         * How it works: Writes "Executed" status into hooks model.
         */
        onAfterRendering: function() {
            this._setHookState("/onAfterRendering", "Executed");
            // alert("Hook triggered: onAfterRendering");
        },

        /**
         * Purpose: Reusable helper to update hook status text.
         * How it works: Sets a property path on the hooks JSON model.
         */
        _setHookState: function(sPath, sValue) {
            // All hook texts are displayed from hooks model in Hook Methods block.
            var oHooksModel = this.getView().getModel("hooks");
            if (oHooksModel) {
                oHooksModel.setProperty(sPath, sValue);
            }
        },

        /**
         * Purpose: Show what user typed in the controls demo input.
         * How it works: Reads input value and shows it in a non-blocking toast.
         */
        onButtonPress: function() {
            // Read from Input control directly using control method getValue().
            var oInput = this.getView().byId("inputField");
            var sValue = oInput.getValue();
            MessageToast.show("Button pressed! Input value: " + sValue);
        },

        /**
         * Purpose: Move from V1 to V2 and carry entered data.
         * How it works: Saves shared model value then navigates with router.
         */
        onNextPress: function() {
            // Save value to shared model so V2 can read it too.
            var oComponent = this.getOwnerComponent();
            var oModel = oComponent.getModel("shared");
            var oInput = this.getView().byId("inputField");
            oModel.setProperty("/inputValue", oInput.getValue());

            // Navigate with router config from manifest.json.
            oComponent.getRouter().navTo("RouteV2");
        },

        /**
         * Purpose: Filter table as user types.
         * How it works: Reads live value from event and passes it to filter helper.
         */
        onTableSearch: function(oEvent) {
            var sQuery = oEvent.getParameter("value") || "";
            this._applyTableSearch(sQuery);
        },

        /**
         * Purpose: Filter table when Search button is clicked.
         * How it works: Reads current input value and applies filter helper.
         */
        onTableSearchPress: function() {
            var sQuery = this.getView().byId("tableSearchInputV1").getValue() || "";
            this._applyTableSearch(sQuery);
        },

        /**
         * Purpose: Perform actual table filtering logic.
         * How it works: Builds OR filters on name/category and applies them to items binding.
         */
        _applyTableSearch: function(sQuery) {
            var oTable = this.getView().byId("demoTableV1");
            var oBinding = oTable.getBinding("items");

            if (!oBinding) {
                return;
            }

            if (!sQuery.trim()) {
                // Empty query means show full list again.
                oBinding.filter([]);
                return;
            }

            // Search in 2 fields and keep rows where name OR category matches.
            var aFilters = [
                new Filter("name", FilterOperator.Contains, sQuery),
                new Filter("category", FilterOperator.Contains, sQuery)
            ];

            oBinding.filter(new Filter({
                filters: aFilters,
                and: false
            }));
        },

        /**
         * Purpose: Update TwoWay model to show instant UI sync.
         * How it works: Writes timestamp value to twoWayModel/baseValue.
         */
        onSetTwoWayModelPress: function() {
            // Update model value to show automatic UI refresh in bound fields.
            this._setBindingModeModelValue("twoWayModel", "TwoWay Updated @ " + new Date().toLocaleTimeString());
        },

        /**
         * Purpose: Reset TwoWay model to initial text.
         * How it works: Writes default value to twoWayModel/baseValue.
         */
        onResetTwoWayModelPress: function() {
            this._setBindingModeModelValue("twoWayModel", "TwoWay Initial Value");
        },

        /**
         * Purpose: Update OneWay model from button action.
         * How it works: Writes timestamp value to oneWayModel/baseValue.
         */
        onSetOneWayModelPress: function() {
            this._setBindingModeModelValue("oneWayModel", "OneWay Updated @ " + new Date().toLocaleTimeString());
        },

        /**
         * Purpose: Reset OneWay model text.
         * How it works: Writes default value to oneWayModel/baseValue.
         */
        onResetOneWayModelPress: function() {
            this._setBindingModeModelValue("oneWayModel", "OneWay Initial Value");
        },

        /**
         * Purpose: Update OneTime source model value.
         * How it works: Writes timestamp value to oneTimeModel/baseValue.
         */
        onSetOneTimeModelPress: function() {
            this._setBindingModeModelValue("oneTimeModel", "OneTime Updated @ " + new Date().toLocaleTimeString());
        },

        /**
         * Purpose: Reset OneTime demo and clear one-time output field.
         * How it works: Resets model value, unbinds output, and empties output text.
         */
        onResetOneTimeModelPress: function() {
            this._setBindingModeModelValue("oneTimeModel", "OneTime Initial Value");
            var oOutput = this.byId("oneTimeOutputInputV1");
            oOutput.unbindProperty("value");
            oOutput.setValue("");
        },

        /**
         * Purpose: Shared writer helper for binding mode models.
         * How it works: Finds model by name and sets /baseValue.
         */
        _setBindingModeModelValue: function(sModelName, sValue) {
            // Model instances are defined in manifest and loaded from webapp/model/*.json.
            var oModel = this.getView().getModel(sModelName) || this.getOwnerComponent().getModel(sModelName);
            if (!oModel) {
                return;
            }

            oModel.setProperty("/baseValue", sValue);
        },

        /**
         * Purpose: Show selected list item details in element-bound box.
         * How it works: Gets selected context path and bindElement on detail container.
         */
        onBindingExamplesSelectionChange: function(oEvent) {
            // Element binding: bind detail box to selected list row path.
            var oSelectedItem = oEvent.getParameter("listItem");
            if (!oSelectedItem) {
                return;
            }

            // getBindingContext("bindingExamples") gets the selected row's data context from that named model.
            // We need this context path so bindElement can point the detail box to exactly that selected object.
            var oContext = oSelectedItem.getBindingContext("bindingExamples");
            if (!oContext) {
                return;
            }

            this.getView().byId("elementBindingBoxV1").bindElement({
                path: oContext.getPath(),
                model: "bindingExamples"
            });
        },

        /**
         * Purpose: Recompute basic string-method outputs.
         * How it works: Calls helper that reads input and writes result fields.
         */
        onApplyBasicMethodsPress: function() {
            // Recalculate outputs from current input string.
            this._updateBasicMethodsResults();
        },

        /**
         * Purpose: Reset basic methods demo to default input.
         * How it works: Sets default input string then recalculates all outputs.
         */
        onResetBasicMethodsPress: function() {
            var oModel = this.getView().getModel("basicMethods");
            if (!oModel) {
                return;
            }

            oModel.setProperty("/inputValue", "  ui5 demo  ");
            this._updateBasicMethodsResults();
        },

        /**
         * Purpose: Run comparison operator calculation.
         * How it works: Calls comparison evaluator helper.
         */
        onEvaluateComparisonPress: function() {
            this._evaluateComparison();
        },

        /**
         * Purpose: Reset comparison block values.
         * How it works: Restores default left/right/operator and reevaluates.
         */
        onResetComparisonPress: function() {
            var oModel = this.getView().getModel("comparisonDemo");
            if (!oModel) {
                return;
            }

            oModel.setProperty("/leftValue", "10");
            oModel.setProperty("/rightValue", "5");
            oModel.setProperty("/operator", ">");
            this._evaluateComparison();
        },

        /**
         * Purpose: Run arithmetic operator calculation.
         * How it works: Calls arithmetic evaluator helper.
         */
        onEvaluateArithmeticPress: function() {
            this._evaluateArithmetic();
        },

        /**
         * Purpose: Reset arithmetic block values.
         * How it works: Restores defaults and reevaluates output.
         */
        onResetArithmeticPress: function() {
            var oModel = this.getView().getModel("arithmeticDemo");
            if (!oModel) {
                return;
            }

            oModel.setProperty("/leftValue", "10");
            oModel.setProperty("/rightValue", "4");
            oModel.setProperty("/operator", "+");
            this._evaluateArithmetic();
        },

        /**
         * Purpose: Run logical operator calculation.
         * How it works: Calls logical evaluator helper.
         */
        onEvaluateLogicalPress: function() {
            this._evaluateLogical();
        },

        /**
         * Purpose: Reset logical block values.
         * How it works: Restores defaults and reevaluates output.
         */
        onResetLogicalPress: function() {
            var oModel = this.getView().getModel("logicalDemo");
            if (!oModel) {
                return;
            }

            oModel.setProperty("/leftValue", "true");
            oModel.setProperty("/rightValue", "false");
            oModel.setProperty("/operator", "&&");
            this._evaluateLogical();
        },

        /**
         * Purpose: Recompute all string-method outputs.
         * How it works: Calls string helper to update result fields in model.
         */
        onApplyStringMethodsPress: function() {
            this._applyStringMethods();
        },

        /**
         * Purpose: Reset string methods block.
         * How it works: Restores default inputs then recalculates outputs.
         */
        onResetStringMethodsPress: function() {
            var oModel = this.getView().getModel("stringMethodsDemo");
            if (!oModel) {
                return;
            }

            oModel.setProperty("/inputValue", "  sap ui5 demo  ");
            oModel.setProperty("/searchValue", "ui5");
            oModel.setProperty("/replaceValue", "fiori");
            this._applyStringMethods();
        },

        /**
         * Purpose: Recompute Math object outputs.
         * How it works: Calls math helper with current number and exponent.
         */
        onApplyMathObjectsPress: function() {
            this._applyMathObjects();
        },

        /**
         * Purpose: Reset math objects block.
         * How it works: Restores default inputs then recalculates outputs.
         */
        onResetMathObjectsPress: function() {
            var oModel = this.getView().getModel("mathObjectsDemo");
            if (!oModel) {
                return;
            }

            oModel.setProperty("/numberValue", "16.7");
            oModel.setProperty("/powerExponent", "2");
            this._applyMathObjects();
        },

        /**
         * Purpose: Show values currently inside demo controls.
         * How it works: Calls getter methods and writes combined text to output model.
         */
        onReadControlMethodsPress: function() {
            // This block demonstrates control APIs directly (getValue/getSelectedKey/getSelected).
            var oInput = this.byId("controlMethodsInputV1");
            var oSelect = this.byId("controlMethodsSelectV1");
            var oCheckBox = this.byId("controlMethodsCheckBoxV1");
            var oModel = this.getView().getModel("controlMethodsDemo");

            if (!oInput || !oSelect || !oCheckBox || !oModel) {
                return;
            }

            var sMessage = "getValue(): " + oInput.getValue() +
                " | getSelectedKey(): " + oSelect.getSelectedKey() +
                " | getSelected(): " + oCheckBox.getSelected();

            oModel.setProperty("/statusText", sMessage);
        },

        /**
         * Purpose: Reset control states using setter methods.
         * How it works: Sets input/select/checkbox back to default values.
         */
        onClearControlMethodsPress: function() {
            // Reset controls with setter methods.
            var oInput = this.byId("controlMethodsInputV1");
            var oSelect = this.byId("controlMethodsSelectV1");
            var oCheckBox = this.byId("controlMethodsCheckBoxV1");
            var oModel = this.getView().getModel("controlMethodsDemo");

            if (!oInput || !oSelect || !oCheckBox || !oModel) {
                return;
            }

            oInput.setValue("");
            oSelect.setSelectedKey("low");
            oCheckBox.setSelected(false);
            oModel.setProperty("/statusText", "Used setValue(), setSelectedKey(), and setSelected() to reset controls.");
        },

        /**
         * Purpose: Toggle enable/disable for control-method demo controls.
         * How it works: Flips boolean flag and applies setEnabled on each control.
         */
        onToggleControlMethodsPress: function() {
            // Toggle enabled/disabled state for multiple controls.
            var oInput = this.byId("controlMethodsInputV1");
            var oSelect = this.byId("controlMethodsSelectV1");
            var oCheckBox = this.byId("controlMethodsCheckBoxV1");
            var oModel = this.getView().getModel("controlMethodsDemo");

            if (!oInput || !oSelect || !oCheckBox || !oModel) {
                return;
            }

            var bEnabled = !!oModel.getProperty("/controlsEnabled");
            var bNextEnabled = !bEnabled;

            oInput.setEnabled(bNextEnabled);
            oSelect.setEnabled(bNextEnabled);
            oCheckBox.setEnabled(bNextEnabled);

            oModel.setProperty("/controlsEnabled", bNextEnabled);
            oModel.setProperty("/statusText", "Used setEnabled(" + bNextEnabled + ") on Input, Select, and CheckBox.");
        },

        /**
         * Purpose: Open reusable message fragment dialog.
         * How it works: Lazy-loads fragment once, keeps promise, and opens dialog.
         */
        onOpenFragmentPress: function() {
            // Fragment demo dialog: lazy-loaded once, then reused.
            var oModel = this.getView().getModel("fragmentDemo");
            if (!this._pDemoDialog) {
                this._pDemoDialog = Fragment.load({
                    id: this.getView().getId(),
                    name: "nagi.demo.view.fragments.DemoDialog",
                    controller: this
                }).then(function(oDialog) {
                    // .then(...) runs after Fragment.load() Promise is fulfilled.
                    // addDependent(...) attaches dialog lifecycle to the view:
                    // when the view is destroyed, this dependent control is cleaned up with it.
                    this.getView().addDependent(oDialog);
                    return oDialog;
                }.bind(this));
            }

            this._pDemoDialog.then(function(oDialog) {
                // This .then(...) waits for dialog readiness and then safely opens it.
                oDialog.open();
                if (oModel) {
                    oModel.setProperty("/statusText", "Fragment opened using Fragment.load().");
                }
            });
        },

        /**
         * Purpose: Save fragment input into output status.
         * How it works: Reads dialog input value, writes model text, then closes dialog.
         */
        onFragmentSubmitPress: function() {
            // Read dialog input and write result back to block output model.
            var oInput = this.byId("fragmentMessageInputV1");
            var sMessage = oInput ? oInput.getValue() : "";
            var oModel = this.getView().getModel("fragmentDemo");

            if (oModel) {
                oModel.setProperty("/statusText", "Fragment value submitted: " + sMessage);
            }

            this.onCloseFragmentPress();
        },

        /**
         * Purpose: Close message fragment dialog.
         * How it works: Uses stored dialog promise and calls close().
         */
        onCloseFragmentPress: function() {
            if (!this._pDemoDialog) {
                return;
            }

            this._pDemoDialog.then(function(oDialog) {
                // .then(...) gives the same cached dialog instance once available; then we close it.
                oDialog.close();
            });
        },

        /**
         * Purpose: Open reusable table fragment dialog.
         * How it works: Lazy-loads table fragment once and opens dialog.
         */
        onOpenTableFragmentPress: function() {
            // Second fragment contains table rows from "test" model (model/testData.json).
            var oModel = this.getView().getModel("fragmentDemo");
            if (!this._pTableDataDialog) {
                this._pTableDataDialog = Fragment.load({
                    id: this.getView().getId(),
                    name: "nagi.demo.view.fragments.TableDataDialog",
                    controller: this
                }).then(function(oDialog) {
                    // .then(...) executes after async fragment load completes.
                    // addDependent(...) registers this dialog under the view for model/context propagation and cleanup.
                    this.getView().addDependent(oDialog);
                    return oDialog;
                }.bind(this));
            }

            this._pTableDataDialog.then(function(oDialog) {
                // Wait for Promise resolution, then open dialog and update status text.
                oDialog.open();
                if (oModel) {
                    oModel.setProperty("/statusText", "Table fragment opened with test model data.");
                }
            });
        },

        /**
         * Purpose: Close table fragment dialog.
         * How it works: Uses stored dialog promise and calls close().
         */
        onCloseTableFragmentPress: function() {
            if (!this._pTableDataDialog) {
                return;
            }

            this._pTableDataDialog.then(function(oDialog) {
                // .then(...) ensures close() is called only after dialog object exists.
                oDialog.close();
            });
        },

        /**
         * Purpose: Copy selected table row data back to Fragment block output.
         * How it works: Reads selected row context, builds summary text, writes fragment model.
         */
        onTableFragmentSelectionChange: function(oEvent) {
            // When a row is selected, copy that row's data back to Fragment block output text.
            var oListItem = oEvent.getParameter("listItem");
            if (!oListItem) {
                return;
            }

            // getBindingContext("test") returns the selected table row context from the "test" model.
            // From that context we can read the exact record data user picked in the fragment table.
            var oContext = oListItem.getBindingContext("test");
            if (!oContext) {
                return;
            }

            var oRecord = oContext.getObject();
            var oModel = this.getView().getModel("fragmentDemo");
            if (oModel) {
                oModel.setProperty(
                    "/statusText",
                    "Selected record: " + oRecord.name + " | " + oRecord.category + " | Qty: " + oRecord.quantity
                );
            }

            this.onCloseTableFragmentPress();
        },

        /**
         * Purpose: Calculate arithmetic result and explanation.
         * How it works: Reads model inputs, applies selected operator, writes result text.
         */
        _evaluateArithmetic: function() {
            // Arithmetic block reads left/right/operator from arithmeticDemo model and writes result fields.
            var oModel = this.getView().getModel("arithmeticDemo");
            if (!oModel) {
                return;
            }

            var nLeft = Number(oModel.getProperty("/leftValue"));
            var nRight = Number(oModel.getProperty("/rightValue"));
            var sOperator = oModel.getProperty("/operator");

            // Number.isNaN(...) checks if conversion failed (input is not a valid number).
            // If either side is invalid, we stop calculation and show a friendly validation message.
            if (Number.isNaN(nLeft) || Number.isNaN(nRight)) {
                oModel.setProperty("/result", "Invalid number input");
                oModel.setProperty("/explanation", "Enter valid numeric values for both operands.");
                return;
            }

            var vResult;
            var sExplanation;

            switch (sOperator) {
                case "+":
                    vResult = nLeft + nRight;
                    sExplanation = "Addition of left and right values.";
                    break;
                case "-":
                    vResult = nLeft - nRight;
                    sExplanation = "Subtraction of right value from left value.";
                    break;
                case "*":
                    vResult = nLeft * nRight;
                    sExplanation = "Multiplication of left and right values.";
                    break;
                case "/":
                    if (nRight === 0) {
                        oModel.setProperty("/result", "Undefined");
                        oModel.setProperty("/explanation", "Division by zero is not allowed.");
                        return;
                    }
                    vResult = nLeft / nRight;
                    sExplanation = "Division of left value by right value.";
                    break;
                case "%":
                    if (nRight === 0) {
                        oModel.setProperty("/result", "Undefined");
                        oModel.setProperty("/explanation", "Modulo by zero is not allowed.");
                        return;
                    }
                    vResult = nLeft % nRight;
                    sExplanation = "Remainder after dividing left value by right value.";
                    break;
                default:
                    vResult = "N/A";
                    sExplanation = "Unsupported arithmetic operator.";
            }

            oModel.setProperty("/result", String(vResult));
            oModel.setProperty("/explanation", sExplanation);
        },

        /**
         * Purpose: Calculate logical result and explanation.
         * How it works: Converts model inputs to booleans, applies operator, writes output.
         */
        _evaluateLogical: function() {
            // Logical block supports &&, || and ! operations.
            var oModel = this.getView().getModel("logicalDemo");
            if (!oModel) {
                return;
            }

            var bLeft = String(oModel.getProperty("/leftValue")).toLowerCase() === "true";
            var bRight = String(oModel.getProperty("/rightValue")).toLowerCase() === "true";
            var sOperator = oModel.getProperty("/operator");

            var vResult;
            var sExplanation;

            switch (sOperator) {
                case "&&":
                    vResult = bLeft && bRight;
                    sExplanation = "Returns true only when both values are true.";
                    break;
                case "||":
                    vResult = bLeft || bRight;
                    sExplanation = "Returns true when at least one value is true.";
                    break;
                case "!":
                    vResult = !bLeft;
                    sExplanation = "Logical NOT inverts the left value and ignores the right value.";
                    break;
                default:
                    vResult = false;
                    sExplanation = "Unsupported logical operator.";
            }

            oModel.setProperty("/result", String(vResult));
            oModel.setProperty("/resultType", typeof vResult);
            oModel.setProperty("/explanation", sExplanation);
        },

        /**
         * Purpose: Compute all string-method demonstration outputs.
         * How it works: Reads input/search/replace and writes trim/upper/lower/etc. results.
         */
        _applyStringMethods: function() {
            // String block computes many outputs from one source string.
            var oModel = this.getView().getModel("stringMethodsDemo");
            if (!oModel) {
                return;
            }

            var sInput = oModel.getProperty("/inputValue") || "";
            var sSearch = oModel.getProperty("/searchValue") || "";
            var sReplace = oModel.getProperty("/replaceValue") || "";
            var sTrimmed = sInput.trim();

            oModel.setProperty("/trimmedValue", sTrimmed);
            oModel.setProperty("/upperCaseValue", sTrimmed.toUpperCase());
            oModel.setProperty("/lowerCaseValue", sTrimmed.toLowerCase());
            oModel.setProperty("/lengthValue", String(sTrimmed.length));
            oModel.setProperty("/includesValue", sSearch ? String(sTrimmed.includes(sSearch)) : "false");
            oModel.setProperty("/replaceResult", sSearch ? sTrimmed.replace(sSearch, sReplace) : sTrimmed);
            oModel.setProperty("/sliceValue", sTrimmed.slice(0, 5));
        },

        /**
         * Purpose: Compute all Math-object demonstration outputs.
         * How it works: Reads number inputs and writes sqrt/pow/round/floor/ceil/... values.
         */
        _applyMathObjects: function() {
            // Math block computes outputs using JavaScript Math object methods.
            var oModel = this.getView().getModel("mathObjectsDemo");
            if (!oModel) {
                return;
            }

            var nValue = Number(oModel.getProperty("/numberValue"));
            var nExponent = Number(oModel.getProperty("/powerExponent"));

            // Guard clause: both inputs must be real numbers before using Math methods.
            // Number.isNaN(...) prevents invalid math output from non-numeric user input.
            if (Number.isNaN(nValue) || Number.isNaN(nExponent)) {
                oModel.setProperty("/sqrtValue", "Invalid number input");
                oModel.setProperty("/powValue", "Invalid number input");
                oModel.setProperty("/roundValue", "Invalid number input");
                oModel.setProperty("/floorValue", "Invalid number input");
                oModel.setProperty("/ceilValue", "Invalid number input");
                oModel.setProperty("/absValue", "Invalid number input");
                oModel.setProperty("/randomValue", "N/A");
                oModel.setProperty("/maxValue", "Invalid number input");
                oModel.setProperty("/minValue", "Invalid number input");
                return;
            }

            var nSafeSqrt = nValue < 0 ? NaN : Math.sqrt(nValue);

            // If input is negative, sqrt gives NaN; Number.isNaN detects that and we show explanatory text.
            oModel.setProperty("/sqrtValue", Number.isNaN(nSafeSqrt) ? "NaN (negative input)" : String(nSafeSqrt));
            oModel.setProperty("/powValue", String(Math.pow(nValue, nExponent)));
            oModel.setProperty("/roundValue", String(Math.round(nValue)));
            oModel.setProperty("/floorValue", String(Math.floor(nValue)));
            oModel.setProperty("/ceilValue", String(Math.ceil(nValue)));
            oModel.setProperty("/absValue", String(Math.abs(nValue)));
            oModel.setProperty("/randomValue", String(Math.random()));
            oModel.setProperty("/maxValue", String(Math.max(nValue, nExponent)));
            oModel.setProperty("/minValue", String(Math.min(nValue, nExponent)));
        },

        /**
         * Purpose: Calculate comparison result and explanation.
         * How it works: Reads left/right/operator, performs comparison, writes result fields.
         */
        _evaluateComparison: function() {
            // Comparison block demonstrates loose/strict and numeric comparison operators.
            var oModel = this.getView().getModel("comparisonDemo");
            if (!oModel) {
                return;
            }

            var sLeftRaw = oModel.getProperty("/leftValue");
            var sRightRaw = oModel.getProperty("/rightValue");
            var sOperator = oModel.getProperty("/operator");
            var nLeft = Number(sLeftRaw);
            var nRight = Number(sRightRaw);

            var vResult;
            var sExplanation;

            switch (sOperator) {
                case "==":
                    vResult = sLeftRaw == sRightRaw;
                    sExplanation = "Loose equality with type coercion.";
                    break;
                case "===":
                    vResult = sLeftRaw === sRightRaw;
                    sExplanation = "Strict equality without type coercion.";
                    break;
                case "!=":
                    vResult = sLeftRaw != sRightRaw;
                    sExplanation = "Loose inequality with type coercion.";
                    break;
                case "!==":
                    vResult = sLeftRaw !== sRightRaw;
                    sExplanation = "Strict inequality without type coercion.";
                    break;
                case ">":
                    vResult = nLeft > nRight;
                    sExplanation = "Greater than comparison.";
                    break;
                case "<":
                    vResult = nLeft < nRight;
                    sExplanation = "Less than comparison.";
                    break;
                case ">=":
                    vResult = nLeft >= nRight;
                    sExplanation = "Greater than or equal comparison.";
                    break;
                case "<=":
                    vResult = nLeft <= nRight;
                    sExplanation = "Less than or equal comparison.";
                    break;
                default:
                    vResult = false;
                    sExplanation = "Unsupported operator.";
            }

            oModel.setProperty("/result", String(vResult));
            oModel.setProperty("/resultType", typeof vResult);
            oModel.setProperty("/explanation", sExplanation);
        },

        /**
         * Purpose: Update simple string utility outputs for basic methods demo.
         * How it works: Reads one input and writes trim/uppercase/length/includes/replace results.
         */
        _updateBasicMethodsResults: function() {
            // Basic string helpers shown in "Basic Methods" style demo.
            var oModel = this.getView().getModel("basicMethods");
            if (!oModel) {
                return;
            }

            var sInput = oModel.getProperty("/inputValue") || "";
            var sTrimmed = sInput.trim();
            oModel.setProperty("/trimmedValue", sTrimmed);
            oModel.setProperty("/upperCaseValue", sTrimmed.toUpperCase());
            oModel.setProperty("/valueLength", sTrimmed.length);
            oModel.setProperty("/includesUi5", sTrimmed.toLowerCase().includes("ui5") ? "Yes" : "No");
            oModel.setProperty("/replacedValue", sTrimmed.replace("demo", "example"));
        },

        /**
         * Purpose: Apply/remove CSS class from target demo text.
         * How it works: Reads target/style from button customData and toggles class.
         */
        onToggleCssStyle: function(oEvent) {
            // Button has custom data telling which text control and CSS class to toggle.
            var oButton = oEvent.getSource();
            var aCustomData = oButton.getCustomData();
            var sTargetId = "";
            var sStyleClass = "";

            aCustomData.forEach(function(oData) {
                if (oData.getKey() === "targetId") {
                    sTargetId = oData.getValue();
                }
                if (oData.getKey() === "styleClass") {
                    sStyleClass = oData.getValue();
                }
            });

            var oTarget = this.byId(sTargetId);
            if (!oTarget || !sStyleClass) {
                return;
            }

            oTarget.toggleStyleClass(sStyleClass);
            oButton.setText(oTarget.hasStyleClass(sStyleClass) ? "Remove" : "Apply");
        },

        /**
         * Purpose: Cleanup when leaving V1 view.
         * How it works: Updates hook status and destroys fragment instances to avoid leaks.
         */
        onExit: function() {
            // Keep hook status visible and free fragment resources when leaving the page.
            this._setHookState("/onExit", "Executed");
            if (this._pDemoDialog) {
                this._pDemoDialog.then(function(oDialog) {
                    // During cleanup, .then(...) waits for async-created dialog before destroy().
                    oDialog.destroy();
                });
                this._pDemoDialog = null;
            }
            if (this._pTableDataDialog) {
                this._pTableDataDialog.then(function(oDialog) {
                    // Same pattern: resolve Promise first, then destroy the table dialog safely.
                    oDialog.destroy();
                });
                this._pTableDataDialog = null;
            }
            // alert("Hook triggered: onExit");
        }
    });
});