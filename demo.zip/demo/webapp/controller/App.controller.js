// sap.ui.define creates a UI5 module file.
// Array items are dependencies to load first; callback parameters receive those loaded modules.
sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  // "use strict" enables safer JavaScript rules and catches common mistakes early.
  "use strict";

  // BaseController.extend(...) creates our App controller class and returns it to UI5.
  return BaseController.extend("nagi.demo.controller.App", {
      // Quick line guide for this file:
      // onInit() -> controller lifecycle hook called once when App view is created.
      // Empty method is intentional because this shell view only hosts routed pages.
      /**
       * Purpose: Root app shell controller hook.
       * How it works: Runs once when App view is created; currently no extra logic is needed.
       */
      onInit() {
      }
  });
});