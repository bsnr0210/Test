// sap.ui.define creates a UI5 module file.
// Array items are dependencies to load first; callback parameters receive those loaded modules.
sap.ui.define([
    "sap/ui/core/mvc/Controller"
], (Controller) => {
    // "use strict" enables safer JavaScript rules and catches common mistakes early.
    "use strict";

    // Controller.extend(...) creates our V2 controller class and returns it to UI5.
    return Controller.extend("nagi.demo.controller.V2", {
        // Quick line guide for this file:
        // this.getOwnerComponent() -> access application component.
        // .getRouter() -> get router instance defined in manifest.
        // .navTo("RouteV1") -> navigate back to V1 route target.
        /**
         * Purpose: Navigate user back from V2 to V1.
         * How it works:
         * 1) getOwnerComponent() gets the app component.
         * 2) getRouter() gets router configured in manifest.
         * 3) navTo("RouteV1") opens V1 view target.
         */
        onBackPress: function() {
            this.getOwnerComponent().getRouter().navTo("RouteV1");
        }
    });
});