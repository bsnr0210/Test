# Methods Guide (Easy for Kids)

This file explains how to read methods in controllers.

## How to read one method quickly
1. Read the `Purpose` line first.
2. Read the `How it works` line next.
3. Then read the code lines inside the method.

## Method naming pattern
- `on...Press` or `on...Change`
  - Event handlers (called by button click, input change, table selection)
- `_...`
  - Helper methods (internal reusable logic)

## Controller map
- `V1.controller.js`
  - Main demo logic for all blocks (controls, binding, scripts, CSS, fragments)
- `V2.controller.js`
  - Back navigation only
- `App.controller.js`
  - Root app controller (app shell hook)
- `Component.js`
  - App startup: sets global models and starts routing
- `model/models.js`
  - Helper methods that create reusable models (like `device`)

## Typical flow example
- User clicks a button in XML view.
- XML `press="onSomethingPress"` calls controller method.
- Method reads model/control values.
- Method writes result to model with `setProperty`.
- Bound UI fields update automatically.

## Data flow reminder
- Models are declared in `manifest.json`.
- Data files are in `webapp/model/*.json`.
- Controllers use `getModel("name")` and `setProperty("/path", value)`.

## Control methods (very important)

These are the exact methods you asked about.

- `this.getView()`
  - Purpose: Get the current page/view object.
  - Use when: You need something that belongs to this view.
  - Example:
    - `this.getView().getModel("shared")`

- `this.byId("controlId")`
  - Purpose: Find one control in this view by id.
  - Use when: You want to read or change that control.
  - Example:
    - `this.byId("tableSearchInputV1").getValue()`

- `oTable.getBinding("items")`
  - Purpose: Get binding object for table rows.
  - Use when: You want to filter/sort list or table data.
  - Example:
    - `oBinding.filter([...])`

- `this.getView().getModel("modelName")`
  - Purpose: Get a named model.
  - Use when: You need read/write data in JSON model.
  - Example:
    - `var oModel = this.getView().getModel("comparisonDemo")`

- `oModel.getProperty("/path")`
  - Purpose: Read one value from model.
  - Example:
    - `oModel.getProperty("/leftValue")`

- `oModel.setProperty("/path", value)`
  - Purpose: Write one value to model.
  - Why useful: Bound controls update automatically.
  - Example:
    - `oModel.setProperty("/result", "true")`

- `control.bindProperty("value", {...})`
  - Purpose: Bind one property (like Input value) to model data.
  - Use when: You want TwoWay/OneWay/OneTime demonstrations.

- `control.bindElement({...})`
  - Purpose: Set one object context for a container.
  - Use when: Child controls should read relative fields from selected object.

## Tiny flow example with these methods
1. `this.byId("demoTableV1")` finds the table.
2. `oTable.getBinding("items")` gets row binding.
3. `oBinding.filter(...)` filters rows.
4. UI shows filtered rows immediately.

## Complete app method map (where to look)

- `Component.js -> init()`
  - Starts app lifecycle.
  - Uses `this.setModel(...)` for global model and `this.getRouter().initialize()` for navigation.

- `App.controller.js -> onInit()`
  - Root shell hook; place app-wide startup logic here if needed later.

- `V2.controller.js -> onBackPress()`
  - Uses `getOwnerComponent()`, `getRouter()`, and `navTo("RouteV1")`.

- `model/models.js -> createDeviceModel()`
  - Creates device model from `sap/ui/Device`.
  - Sets OneWay because device data is read-only for the UI.

## Router methods in simple words
- `getOwnerComponent()` -> get the app container object.
- `getRouter()` -> get navigator object configured in manifest.
- `navTo("RouteName")` -> open another page based on route name.
