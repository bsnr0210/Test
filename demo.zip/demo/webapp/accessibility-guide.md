# Accessibility Guide (Applied in This Demo)

This document explains accessibility best practices used in this app.

## 1) Clear labels for form controls
- Every input/select/checkbox in forms is paired with a `Label`.
- Why: Screen readers can announce what each control means.

## 2) Explicit ARIA labels on list and table controls
- Added `ariaLabelledBy` to key aggregations:
  - Main binding list (`aggregationListV1`)
  - Main table (`demoTableV1`)
  - Table in fragment (`tableDataFragmentTableV1`)
- Why: Screen readers get a meaningful label context when reading rows/items.

## 3) Dialog accessibility improvements
- Fragment dialogs now have:
  - `ariaLabelledBy` to connect dialog with descriptive text
  - `initialFocus` to move keyboard focus to a useful control
- Why: Better keyboard flow and clearer context for assistive technologies.

## 4) Non-blocking user feedback
- `MessageToast` is used instead of browser `alert`.
- Why: Better user experience and avoids disruptive modal browser dialogs.

## 5) Keyboard-friendly interactions
- Selection controls use standard SAPUI5 behaviors (`SingleSelectMaster`, buttons with text labels).
- Why: Works predictably for keyboard users.

## 6) Responsive design basics
- Removed hard fixed width from V2 form.
- Why: Better experience on desktop, tablet, and phone.

## 7) i18n best practice
- Added default English fallback bundle (`i18n_en.properties`).
- Why: Clean build and safer text fallback behavior.

## Quick review checklist
- Every interactive control has a visible label.
- Important tables/lists/dialogs use `ariaLabelledBy`.
- Dialogs define `initialFocus`.
- No browser `alert` for normal UI feedback.
- UI works with keyboard only.
- Texts come from i18n where practical.
